Para el tda cola se tomara en cuenta las siguientes convenciones:

Para poder compilar y ejecutar las pruebas debera ingresar con la siguiente linea de compilacion:
    gcc *.c -o cola -g -std=c99 -Wall -Wconversion -Wtype-limits -pedantic -Werror -O0
y luego:
    valgrind --leak-check=full --track-origins=yes --show-reachable=yes ./cola

Las pruebas estan distribuidas en 4 partes: por un lado se testean las funciones del tda cola con parametros null,
luego se testean cuando la cola esta vacia(ej: cuando se llama a la funcion desencolar que sucede cuando la cola viene vacia),
luego se probara con pocos elementos y para final con muchos elementos.En los 4 casos se testean casos bordes como normales
donde se verifica el correcto funcionamiento de cada una de las fucniones del tda cola.

El formato de las pruebas se baso en el criterio de DADA-CUANDO-ENTONCES. Con respecto a dada se refiere a una situacion inicializal
en donde se inicializarana los datos correspondientes.(ej:Dada una pila null), Cuando es donde se testesta las determianas
funciones a probar en base de algun hecho(ej:cuando se pocos encolan elementos) y entonces es donde se verifica el correcto
funcionanmiento de la funcion testeada.Si la funcion cumplio con lo esperado devolvera 1, lo cual implica que paso la prueba,
sino devolvera cero que fue el estado inicual de la prueba(ej: entonces devlvera null).
